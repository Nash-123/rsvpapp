# rsvpapp
RSVP app by CloudYuga

## Credits
Thanks to [Anand Chitipothu](https://twitter.com/anandology) for helping us with the application development. 
